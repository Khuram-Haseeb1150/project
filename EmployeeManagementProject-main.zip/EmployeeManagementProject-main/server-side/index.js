const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const path = require("path");
const EmployeeEntry = require("./schema/EmployeeEntry");

require("dotenv").config();
let env = process.env;

const app = express();
app.use("/public", express.static(__dirname + "/public"));
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use("/public", express.static("public"));

app.set("port", process.env.PORT || 3001);

mongoose.connect(env.Mongoose_URL, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
mongoose.connection
  .once("open", () => {
    console.log("Yahooo! Connection is Established.");
  })
  .on("error", (err) => {
    console.log("Err: ", err);
  });

app.get("/", (req, res) => {
  res.send("Running...");
});

app.post("/addEmployee", (req, res) => {
  console.log(req.body);
  
  const AddEmployee = new EmployeeEntry({
    id: req.body.id,
    firstName: req.body.firstName,
    lastname: req.body.lastname,
    fatherName: req.body.fatherName,
    cell: req.body.cell,
    department: req.body.department,
    designation: req.body.designation,
    isActive: true,
    createdDate: req.body.createdDate, //new Date;
    adminId: req.body.adminId,
  });
  
  AddEmployee.save()
  .then((data) => {
    console.log("saved user", data);
    res.send(data);
  })
  .catch((err) => {
    console.log("Err ", err);
    res.send(err);
  });
  // res.send(req.body)
});

app.listen(app.get("port"), function () {
  console.log(`Server Started on: http://localhost:${app.get("port")}`);
});
