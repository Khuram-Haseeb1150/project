import React from 'react'

const NotFound = () => {
    return (
        <div className="App">
            <h1>Path Not Found, Something is wrong with your URL</h1>
        </div>
    )
}

export default NotFound
