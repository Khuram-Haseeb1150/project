import React, { useState } from "react";
import { Form, Formik, useFormik } from "formik";
import * as Yup from "yup";
import axios from "axios";
import globalData from "./../globalData.json";
import {
  Button,
  Paper,
  Container,
  Box,
  TextField,
  MenuItem,
} from "@material-ui/core";
import NumberFormatCustom from "../features/NumberFormatCustom";

const RegistrationForm = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");

  const phoneRegExp = /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;

  const initialValues = {
    firstName: "",
    lastName: "",
    fatherName: "",
    department: "",
    designation: "",
    cell: "03",
    isActive: true,
    adminId: "",
    createdDate: "",
  };

  const department = [
    {
      id: 1,
      department: "Graphics Designer",
    },
    {
      id: 2,
      department: "MERN Stack Develper",
    },
    {
      id: 3,
      department: "Unity Developer",
    },
  ];

  const designation = [
    {
      id: 1,
      designation: "Internee",
    },
    {
      id: 2,
      designation: "Junior Develper",
    },
    {
      id: 3,
      designation: "Senior Developer",
    },
  ];

  const validationSchema = Yup.object().shape({
    firstName: Yup.string()
      .min(3, "Must be above 3 characters long")
      .max(15, "Must be 15 characters or less")
      .required("Please enter the required field"),
    lastName: Yup.string()
      .min(3, "Must be above 3 characters long")
      .max(15, "Must be 15 characters or less")
      .required("Please enter the required field"),
    fatherName: Yup.string()
      .min(3, "Must be above 3 characters long")
      .max(15, "Must be 15 characters or less")
      .required("Please enter the required field"),
    cell: Yup.string()
      .required("Please enter the required field")
      .matches(phoneRegExp, "Phone number is not valid"),
    createdDate: Yup.date().required("Please enter the required field"),
    department: Yup.string().required("Please enter the required field"),
    designation: Yup.string().required("Please enter the required field"),
    // .oneOf(
    //     ["Graphics Designer", "MERN Stack Develper", "Unity Developer"],
    //     "Department is not valid"
    //   )

    //   .ensure()
    //   .when("department", {
    //     is: undefined,
    //     then: Yup.string().required("Please enter the required field"),
    //   }),
  });

  //   const validationSchema = Yup.object({
  //     email: Yup.string("Enter your email")
  //       .email("Enter a valid email")
  //       .required("Email is required"),
  //     lastName: Yup.string("Enter your lastName")
  //       .min(8, "Password should be of minimum 8 characters length")
  //       .required("Password is required"),
  //   });

  const formSubmit = (values) => {
    console.log(values);
    axios
      .post(`${globalData.url}/addEmployee`, {
        firstName: values.firstName,
        lastname: values.lastname,
        fatherName: values.fatherName,
        cell: values.cell,
        department: values.department,
        designation: values.designation,
        createdDate: values.createdDate,
      })
      .then((json) => console.log("data:", json));
  };

  const formik = useFormik({
    initialValues: initialValues,
    validationSchema: validationSchema,
    onSubmit: formSubmit,
  });

  return (
    <Container maxWidth="md">
      <h1 className="text-center">Add Employee</h1>
      <Paper className="paperStyle" elevation={3}>
        <Box px={10} py={5}>
          <form onSubmit={formik.handleSubmit}>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <TextField
                style={{ marginRight: "30px" }}
                fullWidth
                id="firstName"
                name="firstName"
                label="First Name*"
                value={formik.values.firstName}
                onChange={formik.handleChange}
                error={
                  formik.touched.firstName && Boolean(formik.errors.firstName)
                }
                helperText={formik.touched.firstName && formik.errors.firstName}
              />
              <TextField
                fullWidth
                id="lastName"
                name="lastName"
                label="Last Name*"
                type="string"
                value={formik.values.lastName}
                onChange={formik.handleChange}
                error={
                  formik.touched.lastName && Boolean(formik.errors.lastName)
                }
                helperText={formik.touched.lastName && formik.errors.lastName}
              />
            </div>
            <TextField
              fullWidth
              id="fatherName"
              name="fatherName"
              label="Father Name*"
              type="string"
              value={formik.values.fatherName}
              onChange={formik.handleChange}
              error={
                formik.touched.fatherName && Boolean(formik.errors.fatherName)
              }
              helperText={formik.touched.fatherName && formik.errors.fatherName}
            />
            <TextField
              fullWidth
              label="Cell No*"
              value={formik.values.cell}
              onChange={formik.handleChange}
              name="cell"
              type="tel"
              id="formatted-numberformat-input"
              error={formik.touched.cell && Boolean(formik.errors.cell)}
              helperText={formik.touched.cell && formik.errors.cell}
              InputProps={{
                inputComponent: NumberFormatCustom,
              }}
            />
            <TextField
              fullWidth
              id="createdDate"
              name="createdDate"
              label="Created On*"
              type="date"
              value={formik.values.createdDate}
              onChange={formik.handleChange}
              InputLabelProps={{
                shrink: true,
              }}
              error={
                formik.touched.createdDate && Boolean(formik.errors.createdDate)
              }
              helperText={
                formik.touched.createdDate && formik.errors.createdDate
              }
            />
            <TextField
              fullWidth
              id="department"
              name="department"
              label="Department*"
              type="select"
              select
              value={formik.values.department}
              onChange={formik.handleChange}
              error={
                formik.touched.department && Boolean(formik.errors.department)
              }
              helperText={formik.touched.department && formik.errors.department}
            >
              {department.map((option) => (
                <MenuItem key={option.id} value={option.department}>
                  {option.department}
                </MenuItem>
              ))}
            </TextField>
            <TextField
              fullWidth
              id="designation"
              name="designation"
              label="Designation*"
              type="select"
              select
              value={formik.values.designation}
              onChange={formik.handleChange}
              error={
                formik.touched.designation && Boolean(formik.errors.designation)
              }
              helperText={
                formik.touched.designation && formik.errors.designation
              }
            >
              {designation.map((option) => (
                <MenuItem key={option.id} value={option.designation}>
                  {option.designation}
                </MenuItem>
              ))}
            </TextField>
            <Button
              color="primary"
              variant="contained"
              fullWidth
              type="submit"
              //   disabled={!formik.dirty || !formik.isValid}
            >
              Add Employee
            </Button>
          </form>
        </Box>
      </Paper>
    </Container>
  );
};

export default RegistrationForm;
