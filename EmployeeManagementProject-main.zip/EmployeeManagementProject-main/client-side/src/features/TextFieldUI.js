import React from "react";
import { TextField } from "@material-ui/core";
import { useField } from "formik";

// const useStyles = makeStyles((theme) => ({
//   helperText: {
//     margin: theme.spacing(1), //4 etc
//     color: "red",
//   },
//   //   error: {
//   //     "&.MuiFormHelperText-root.Mui-error": {
//   //       color: theme.palette.common.white,
//   //     },
//   //   },
// }));

const TextFieldUI = ({ formikKey, label, ...props }) => {
    const [field, meta, helpers] = useField(formikKey);
    return <TextField
        id={field.name}
        name={field.name}
        fullWidth={true}
        label={label}
        helperText={meta.touched ? meta.error : ""}
        error={meta.touched && Boolean(meta.error)}
        value={field.value}
        onChange={field.onChange}
        {...props}
    />
}

export default TextFieldUI;
